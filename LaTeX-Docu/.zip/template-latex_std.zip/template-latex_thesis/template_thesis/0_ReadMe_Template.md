# Read Me for Thesis Template
Das hier abgelegte Template bildet die Basis für die jeweilige Thesis. Erläuterungen für die notwendigen Anpassungen findet man im Ordner **manual**.
