# Read Me for Manual Folder
In diesem Ordner liegen die Erläuterungen für die Verwendung des Templates.
